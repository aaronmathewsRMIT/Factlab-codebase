import re
from django.shortcuts import render, redirect
from .models import individual

# Create your views here.
def dbupdate(request):
    return render(request,'dbupdate.html')


def add_record(request):
    if request.method == 'POST':
        claimant = request.POST.get('claimant')
        party = request.POST.get('party')
        print(claimant,party)
        e = individual()
        e.claimant = claimant
        e.party = party
        e.save()
        return redirect("/home")
    else:
        return render(request, 'dbupdate.html')