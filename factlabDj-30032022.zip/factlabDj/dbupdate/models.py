from django.db import models

# Create your models here.

class individual(models.Model):
    individual_id = models.AutoField(primary_key=True)
    claimant = models.CharField(max_length=50)
    party = models.CharField(max_length=50)

    class Meta:
        db_table = 'individual'