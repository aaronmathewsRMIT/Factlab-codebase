from django.shortcuts import render, redirect
# Create your views here.

# Create your views here.
def dbfetch(request):
    return render(request,'dbfetch.html')



def fetchrecord(request):
    if request.method == 'POST':
        claimant = request.POST.get('claimant')
        party = request.POST.get('party')
        print(claimant,party)
        e = individual()
        e.claimant = claimant
        e.party = party
        e.save()
        return redirect("/home")
    else:
        return render(request, 'dbfetch.html')